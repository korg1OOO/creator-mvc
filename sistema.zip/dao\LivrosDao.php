        <?php
            require_once("../model/conexao.php");
            class {nomeClasse}Dao {
                private $con;
                public function __construct() {
                    $this->con = new Conexao();
                }
            function inserir($obj) {
                var_dump($obj);
        }
    }
?>